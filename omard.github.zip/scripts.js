console.log("Blog loaded successfully!");
